import enum


class VolType(enum.IntEnum):
    AVERAGE = 0
    STANDARD = 1


class TimeType(enum.IntEnum):
    IGNORE_WEEKENDS = 0
    FULL_YEAR = 1


class RoutingStatus(enum.Enum):
    BUILDING = "building"
    PENDING = "pending"
    PROCESSING = "processing"
    SENDING = "sending"
    ROUTED = "routed"
    ERROR = "error"


class CallOrPut(enum.IntEnum):
    CALL = 1
    PUT = -1
