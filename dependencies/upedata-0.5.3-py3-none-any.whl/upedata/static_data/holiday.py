from datetime import date
from typing import List

from sqlalchemy import (
    BigInteger,
    Boolean,
    Date,
    Float,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

import upedata.static_data.holiday_association as holiday_association
import upedata.static_data.product as product

from ..base import Base


class Holiday(Base):
    __tablename__ = "holidays"
    holiday_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    holiday_date: Mapped[date] = mapped_column(Date)
    holiday_weight: Mapped[float] = mapped_column(Float, default=1)
    is_closure_date: Mapped[bool] = mapped_column(Boolean, default=True)

    products: Mapped[List["product.Product"]] = relationship(
        secondary=holiday_association.product_holiday_associations,
        back_populates="holidays",
    )
