from datetime import time
from typing import List

from sqlalchemy import ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import Time
from zoneinfo import ZoneInfo

import upedata.dynamic_data.external_pnl as external_pnl
import upedata.static_data.currency as currency
import upedata.static_data.exchange as exchange
import upedata.static_data.future as future
import upedata.static_data.holiday as holiday
import upedata.static_data.option as option
from upedata.static_data.holiday_association import product_holiday_associations

from ..base import Base


class Product(Base):
    __tablename__ = "products"

    symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    short_name: Mapped[str] = mapped_column(Text)
    long_name: Mapped[str] = mapped_column(Text)
    currency_symbol: Mapped[str] = mapped_column(ForeignKey("currencies.symbol"))
    exchange_symbol: Mapped[int] = mapped_column(ForeignKey("exchanges.symbol"))

    # For migration to new locale, replace these two with their underscored
    # and commented friends below, remove the `_aware` from the properties
    # further below, and pray to the good lord that things work
    market_open: Mapped[time] = mapped_column(
        Time(timezone=True),
        default=time(0, 0, 0, 0, tzinfo=ZoneInfo("UTC")),
        name="market_open",
    )
    market_close: Mapped[time] = mapped_column(
        Time(timezone=True),
        default=time(23, 59, 59, 999999, tzinfo=ZoneInfo("UTC")),
        name="market_close",
    )
    market_open_naive: Mapped[time] = mapped_column(
        Time(timezone=False),
        default=time(0, 0, 0, 0),
        name="market_open_naive",
    )
    market_close_naive: Mapped[time] = mapped_column(
        Time(timezone=False),
        default=time(23, 59, 59, 999999),
        name="market_close_naive",
    )
    # _market_open: Mapped[time] = mapped_column(
    #     Time(timezone=False), default=time(0, 0, 0, 0), name="market_open"
    # )
    # _market_close: Mapped[time] = mapped_column(
    #     Time(timezone=False), default=time(23, 59, 59, 999999), name="market_close"
    # )
    locale: Mapped[str] = mapped_column(Text, default="UTC")

    @property
    def market_timezone(self) -> ZoneInfo:
        return ZoneInfo(self.locale)

    @property
    def market_open_aware(self) -> time:
        return self.market_open_naive.replace(tzinfo=self.market_timezone)

    @property
    def market_close_aware(self) -> time:
        return self.market_close_naive.replace(tzinfo=self.market_timezone)

    currency: Mapped["currency.Currency"] = relationship(
        foreign_keys=currency_symbol, back_populates="products", lazy="immediate"
    )
    exchange: Mapped["exchange.Exchange"] = relationship(
        foreign_keys=exchange_symbol, back_populates="products", lazy="immediate"
    )
    holidays: Mapped[List["holiday.Holiday"]] = relationship(
        secondary=product_holiday_associations,
        back_populates="products",
        lazy="immediate",
    )
    futures: Mapped[List["future.Future"]] = relationship(back_populates="product")
    options: Mapped[List["option.Option"]] = relationship(back_populates="product")
    external_pnls: Mapped[List["external_pnl.ExternalPnL"]] = relationship(
        back_populates="product"
    )

    def to_dict(self):
        product_dict = {}
        for field in self.__table__.c:
            product_dict[field.name] = getattr(self, field.name)

        return product_dict
