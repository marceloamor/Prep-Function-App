from datetime import date

from sqlalchemy import Date, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from ..base import Base


class SettlementVol(Base):
    __tablename__ = "settlement_vols"

    settlement_date: Mapped[date] = mapped_column(Date, primary_key=True)
    option_symbol: Mapped[str] = mapped_column(
        ForeignKey("options.symbol"), primary_key=True
    )
    strike: Mapped[float] = mapped_column(Float, primary_key=True)
    volatility: Mapped[float] = mapped_column(Float)
