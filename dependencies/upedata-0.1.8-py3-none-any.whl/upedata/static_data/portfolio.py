import upedata.dynamic_data.position as position
import upedata.static_data.trader as trader
from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Integer, Text, ForeignKey

from typing import List


class Portfolio(Base):
    __tablename__ = "portfolios"

    portfolio_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    display_name: Mapped[str] = mapped_column(Text)
    owner_trader_id: Mapped[int] = mapped_column(ForeignKey("traders.trader_id"))

    owner_trader: Mapped["trader.Trader"] = relationship(
        back_populates="portfolios", lazy="immediate"
    )
    positions: Mapped[List["position.Position"]] = relationship(
        back_populates="portfolio"
    )
