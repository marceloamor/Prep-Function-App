from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import Float, Date, ForeignKey

from datetime import date


class SettlementVol(Base):
    __tablename__ = "settlement_vols"

    settlement_date: Mapped[date] = mapped_column(Date, primary_key=True)
    option_symbol: Mapped[str] = mapped_column(
        ForeignKey("options.symbol"), primary_key=True
    )
    strike: Mapped[float] = mapped_column(Float, primary_key=True)
    volatility: Mapped[float] = mapped_column(Float)
