from upedata.dynamic_data.vol_surface import VolSurface
import upedata.static_data.product as product
import upedata.static_data.future as future
from ..enums import VolType, TimeType
from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import (
    ForeignKey,
    DateTime,
    ARRAY,
    Double,
    Integer,
    Text,
    Enum,
)

from typing import List, Tuple, Optional
from datetime import datetime


class Option(Base):
    __tablename__ = "options"
    symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    display_name: Mapped[Optional[str]] = mapped_column(Text)
    product_symbol: Mapped[str] = mapped_column(ForeignKey("products.symbol"))
    vol_surface_id: Mapped[int] = mapped_column(
        ForeignKey("vol_surfaces.vol_surface_id")
    )
    underlying_future_symbol: Mapped[str] = mapped_column(ForeignKey("futures.symbol"))
    strike_intervals: Mapped[List[Tuple[int, int]]] = mapped_column(
        ARRAY(Integer, dimensions=2)
    )
    time_type: Mapped[TimeType] = mapped_column(Enum(TimeType, name="time_type"))
    multiplier: Mapped[float] = mapped_column(Double)
    vol_type: Mapped[VolType] = mapped_column(Enum(VolType, name="vol_type"))
    expiry: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    product: Mapped["product.Product"] = relationship(
        foreign_keys=product_symbol, back_populates="options", lazy="immediate"
    )
    vol_surface: Mapped["VolSurface"] = relationship(
        foreign_keys=vol_surface_id, lazy="immediate"
    )
    underlying_future: Mapped["future.Future"] = relationship(
        foreign_keys=underlying_future_symbol,
        back_populates="options",
        lazy="immediate",
    )
