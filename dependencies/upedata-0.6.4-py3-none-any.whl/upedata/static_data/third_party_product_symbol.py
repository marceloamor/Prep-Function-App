from sqlalchemy import Enum, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

import upedata.static_data.product as product

from ..base import Base
from ..enums import TradingPlatform as TradingPlatformEnum


class ThirdPartyProductSymbol(Base):
    __tablename__ = "third_party_product_symbols"

    platform_name: Mapped[TradingPlatformEnum] = mapped_column(
        Enum(TradingPlatformEnum, name="trading_platform"), primary_key=True
    )
    platform_symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    product_symbol: Mapped[str] = mapped_column(ForeignKey("products.symbol"))

    product: Mapped["product.Product"] = relationship(foreign_keys=product_symbol)
