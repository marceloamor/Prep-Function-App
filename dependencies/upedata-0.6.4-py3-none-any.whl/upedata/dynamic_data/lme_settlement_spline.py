from datetime import date
from typing import Optional

from sqlalchemy import Date, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from ..base import Base


class LMESettlementSpline(Base):
    __tablename__ = "lme_settlement_spline_params"
    settlement_date: Mapped[date] = mapped_column(Date, primary_key=True)
    option_symbol: Mapped[str] = mapped_column(
        ForeignKey("options.symbol"), primary_key=True
    )
    m10_diff: Mapped[float] = mapped_column(Float)
    m25_diff: Mapped[float] = mapped_column(Float)
    atm_vol: Mapped[float] = mapped_column(Float)
    p25_diff: Mapped[float] = mapped_column(Float)
    p10_diff: Mapped[float] = mapped_column(Float)
    median: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lower: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    highest: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    s1: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    s2: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
