from datetime import date, datetime
from typing import Union

from dateutil.relativedelta import relativedelta

MONTH_CODE_MAPPING = {
    1: "f",
    2: "g",
    3: "h",
    4: "j",
    5: "k",
    6: "m",
    7: "n",
    8: "q",
    9: "u",
    10: "v",
    11: "x",
    12: "z",
}


def map_month_year_coded_plus_one_month(expiry: Union[datetime, date]) -> str:
    expiry += relativedelta(months=1)
    return map_month_year_coded(expiry)


def map_month_year_coded(expiry: Union[datetime, date]) -> str:
    month_code = MONTH_CODE_MAPPING[expiry.month]
    year_final_digit = str(expiry.year)[-1]
    return f"{month_code}{year_final_digit}"


def map_yyyy_mm_dd(expiry: Union[datetime, date]) -> str:
    return expiry.strftime(r"%Y-%m-%d")


def map_yy_mm_dd(expiry: Union[datetime, date]) -> str:
    return expiry.strftime(r"%y-%m-%d")


_LOCAL_FUNCTIONS = {
    "map_month_year_coded": {
        "callable": map_month_year_coded,
        "signature": ((Union[datetime, date],), str),
    },
    "map_month_year_coded_plus_one_month": {
        "callable": map_month_year_coded_plus_one_month,
        "signature": ((Union[datetime, date],), str),
    },
    "map_yyyy_mm_dd": {
        "callable": map_yyyy_mm_dd,
        "signature": ((Union[datetime, date],), str),
    },
    "map_yy_mm_dd": {
        "callable": map_yy_mm_dd,
        "signature": ((Union[datetime, date],), str),
    },
}
