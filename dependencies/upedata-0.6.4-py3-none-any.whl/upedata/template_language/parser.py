import copy
import re
from functools import partial
from typing import Any, Callable, Dict, List, Tuple, Union, overload

from upedata.static_data import Future, Option
from upedata.template_language import utils


class BadTemplateStatement(Exception):
    pass


class BadInputObject(Exception):
    pass


def build_preprocessor_for_matched_internal_function(
    loc_func: Callable[..., str],
    static_pattern_replacement_set: List[Tuple[re.Pattern[str], Any]],
    match_data: re.Match[str],
) -> str:
    arg_list = []
    for group_name, group_data in match_data.groupdict().items():
        assert isinstance(
            group_data, str
        ), "Found non-string/unmatched argument data in function call"
        for pattern, replacement_data in static_pattern_replacement_set:
            if pattern.fullmatch(r"#{" + group_data + r"}£"):
                arg_list.append(replacement_data)
    return loc_func(*arg_list)


def build_future_field_substitutions(
    future: Future,
) -> List[Tuple[re.Pattern[str], Union[str, Callable[[re.Match[str]], str]]]]:
    future_data_dict = future.to_dict()
    pattern_repl_list: List[Tuple[re.Pattern[str], Any]] = []
    for col_name, col_data in future_data_dict.items():
        pattern_repl_list.append(
            (re.compile(r"#{<future>." + col_name + r"}£"), col_data)
        )
    for col_name, col_data in future.product.to_dict().items():
        pattern_repl_list.append(
            (re.compile(r"#{<future>.product." + col_name + r"}£"), col_data)
        )
    static_pattern_replacement_set = copy.deepcopy(pattern_repl_list)
    for local_func_name, local_func_data in utils._LOCAL_FUNCTIONS.items():
        local_func_pattern = r"^#\{(?P<func_name>" + local_func_name + r"){1}\("
        num_args = len(local_func_data["signature"][0])
        for i in range(num_args):
            local_func_pattern += f"(?P<arg{i}>.*?)"
            if i + 1 < num_args:
                # means we're not at the final argument so need to add a comma to capturing
                local_func_pattern += ", "
        local_func_pattern += ""
        local_func_pattern += r"\)}£"
        partial_preprocess_func = partial(
            build_preprocessor_for_matched_internal_function,
            local_func_data["callable"],
            static_pattern_replacement_set,
        )
        pattern_repl_list.append(
            (
                re.compile(local_func_pattern),
                partial_preprocess_func,
            )
        )

    return pattern_repl_list


def build_option_field_substitutions(
    option: Option,
) -> List[Tuple[re.Pattern[str], Union[str, Callable[[re.Match[str]], str]]]]:
    option_data_dict = option.to_dict()
    pattern_repl_list: List[Tuple[re.Pattern[str], Any]] = []
    for col_name, col_data in option_data_dict.items():
        pattern_repl_list.append(
            (re.compile(r"#{<option>." + col_name + r"}£"), col_data)
        )
    for col_name, col_data in option.product.to_dict().items():
        pattern_repl_list.append(
            (re.compile(r"#{<option>.product." + col_name + r"}£"), col_data)
        )
    for col_name, col_data in option.underlying_future.to_dict().items():
        pattern_repl_list.append(
            (re.compile(r"#{<option>.underlying_future." + col_name + r"}£"), col_data)
        )
    static_pattern_replacement_set = copy.deepcopy(pattern_repl_list)
    for local_func_name, local_func_data in utils._LOCAL_FUNCTIONS.items():
        local_func_pattern = r"^#\{(?P<func_name>" + local_func_name + r"){1}\("
        num_args = len(local_func_data["signature"][0])
        for i in range(num_args):
            local_func_pattern += f"(?P<arg{i}>.*?)"
            if i + 1 < num_args:
                # means we're not at the final argument so need to add a comma to capturing
                local_func_pattern += ", "
        local_func_pattern += ""
        local_func_pattern += r"\)}£"
        partial_preprocess_func = partial(
            build_preprocessor_for_matched_internal_function,
            local_func_data["callable"],
            static_pattern_replacement_set,
        )
        pattern_repl_list.append(
            (
                re.compile(local_func_pattern),
                partial_preprocess_func,
            )
        )

    return pattern_repl_list


def build_derivative_field_substitutions(
    derivative: Union[Future, Option],
) -> List[Tuple[re.Pattern[str], Union[str, Callable[[re.Match[str]], str]]]]:
    if isinstance(derivative, Future):
        return build_future_field_substitutions(derivative)
    elif isinstance(derivative, Option):
        return build_option_field_substitutions(derivative)
    else:
        raise BadInputObject(
            "Received unexpected derivative object of type not in Union[Future, Option]"
        )


class TokenizedString:
    tokenizer_regex = re.compile(
        r"(?P<gen_stmt>#{[^\$]*?}\£)|(?P<late_stmt>@{[^\$]*?}\£)|(?P<raw_str>[^$#@]+)"
    )
    subtracted_string: str = ""
    generation_time_operations: Dict[str, str] = {}
    late_evaluation_dynamic_stmts: Dict[str, str] = {}

    def __init__(self, input_string: str):
        tokenized_string: str = ""
        substitution_counter = 0
        for lang_match in self.tokenizer_regex.finditer(input_string):
            for group_name, captured_str in lang_match.groupdict().items():
                if captured_str is None:
                    continue
                match group_name:
                    case "gen_stmt":
                        sub_key = "gen_stmt_" + str(substitution_counter)
                        tokenized_string += "{" + sub_key + "}"
                        self.generation_time_operations[sub_key] = captured_str
                        substitution_counter += 1
                    case "late_stmt":
                        sub_key = "late_stmt_" + str(substitution_counter)
                        tokenized_string += "{" + sub_key + "}"
                        self.late_evaluation_dynamic_stmts[sub_key] = captured_str
                        substitution_counter += 1
                    case "raw_str":
                        tokenized_string += captured_str

        self.subtracted_string = tokenized_string


def tokenize(input_data: str) -> TokenizedString:
    """Generate a `TokenizedString` object used for dynamic name substitution,
    the primitive language used for this is as follows:

    `#{statement}£` is a statement to run before entry into static data, this should
    only be used within Prep or other data entry services as it runs before database
    entry.
    Capture group is defined by `#{` as the statement opener and `}£` as the closer.

    `@{statement}£` is a statement to run after retrieval from static data, this is
    usually reserved for fields such as `strike` and `call_or_put` found on individual
    option instruments, which are not represented in the database.
    This will be found in static data and must be processed by services creating
    and/or naming option objects.
    Capture group is defined by `@{` as the statement opener and `}£` as the closer.

    A limited set of operations are possible in all statements, functions found in the
    `upedata.template_language.utils` can be addressed directly permitting their
    arguments are validated against stored patterns.

    Other fields that can be accessed are those native to the `Option` or `Future`
    static data object, addressed with `<option|future>.field` in both `#` and `@`
    statements.
    In addition to these basic fields, options can reference their `<option>.product`
    and `<option>.underlying_future`, all data stored in the relevant rows is also
    retrievable via `<option>.sub_object.field`.

    For options, `@` statements can also support `{strike}`, `{call_or_put}`, and
    others depending on the instrument being generated and which service is
    generating it, usually this data is provided downstream and is static.

    Non-statement strings will be treated as raw strings and are greedily
    captured until the next statement opener (`#{` or `@{`).

    Statements are processed sequentially depending on type and results are
    substituted into the base string at the conclusion of operations.

    There may be only one callable per statement, but a callable may have multiple
    dynamic arguments separated by commas with the final argument lacking one.

    Statements may also not nest other statements.

    :param input_data: Input string to be parsed into a token set
    :type input_data: str
    :return: `TokenizedString` for use in processing functions
    :rtype: TokenizedString
    """
    return TokenizedString(input_data)


def populate_tokenized_gen_time(
    tokenized_display_name: TokenizedString,
    regex_substitutions: List[
        Tuple[re.Pattern[str], Union[str, Callable[[re.Match[str]], str]]]
    ],
) -> TokenizedString:
    for (
        gen_time_key,
        matched_string,
    ) in tokenized_display_name.generation_time_operations.items():
        for pattern, replacement in regex_substitutions:
            if pattern.fullmatch(matched_string):
                if matched_string is None:
                    raise BadTemplateStatement(
                        f"Unable to match `{pattern.pattern}` to replacement data: `{replacement}`",
                    )
                if replacement is None:
                    raise BadInputObject(
                        f"Pattern `{pattern.pattern}` lacked replacement data: `{replacement}`",
                    )
                tokenized_display_name.generation_time_operations[
                    gen_time_key
                ] = pattern.sub(replacement, matched_string)
                break

    combined_substitution_dict = (
        tokenized_display_name.generation_time_operations
        | tokenized_display_name.late_evaluation_dynamic_stmts
    )
    tokenized_display_name.subtracted_string = (
        tokenized_display_name.subtracted_string.format(**combined_substitution_dict)
    )

    return tokenized_display_name


# This just allows downstream type hinting to realise that Option -> Option and
# Future -> Future, rather than (Option | Future) -> (Option | Future)
@overload
def substitute_derivative_generation_time(option_or_future: Option) -> Option:
    ...


@overload
def substitute_derivative_generation_time(option_or_future: Future) -> Future:
    ...


def substitute_derivative_generation_time(
    option_or_future: Union[Option, Future]
) -> Union[Option, Future]:
    """Substitutes in gen-time data into `option.display_name` as described
    in `parser.tokenize`.

    None of this will error well, apologies in advance for horrible to deal with
    bugs, but it's the only way I could think of to avoid using dangerous stuff
    like `eval`.

    :param option: Option or Future static data object
    :type option: Union[Option, Future]
    :return: Input option but with `display_name` processed according to given rules
    :rtype: Union[Option, Future]
    """

    if option_or_future.display_name is None:
        return option_or_future

    tokenized_display_name = tokenize(option_or_future.display_name)
    if isinstance(option_or_future, Option):
        option_substitutions = build_option_field_substitutions(option_or_future)
    elif isinstance(option_or_future, Future):
        option_substitutions = build_future_field_substitutions(option_or_future)
    else:
        raise BadInputObject(
            f"Passed object that was not either `Option` or `Future`, was "
            f"`{type(option_or_future)}`",
        )

    tokenized_display_name = populate_tokenized_gen_time(
        tokenized_display_name, option_substitutions
    )
    option_or_future.display_name = tokenized_display_name.subtracted_string

    return option_or_future


def generate_display_names_late_evaluation(option: Option, **kwargs) -> List[str]:
    """Given an option object and a set of keyword arguments, parses late
    evaluation templates in the `display_name` and returns a list of all
    display names in-line with the list length of inputs.

    Keyword argument names must match perfectly the late evaluation names in
    the option display name, sans `@{` and `}£`.
    The length of these lists must match, individual values can be passed
    in on these kwargs to be cast to the list length expected.
    If none of the kwarg inputs are of type `List` then a single element
    List will be returned.

    :param option: Option object to be used for late evaluation of display
    name
    :type option: Option
    :return: List of display names corresponding to kwarg inputs
    :rtype: List[str]
    """
    if option.display_name is None:
        raise ValueError("Option provided with no set `display_name`")

    replacement_data_list_lengths = []
    for identifier, replacement_data in kwargs.items():
        if not isinstance(replacement_data, list):
            replacement_data = [replacement_data]
        if (
            replacement_data_list_lengths
            and len(replacement_data)
            not in (
                max(replacement_data_list_lengths),
                1,
            )
            and max(replacement_data_list_lengths) != 1
        ):
            raise ValueError(
                f"Input kwarg with name: `{identifier}` did not match the length of other kwargs"
            )
        replacement_data_list_lengths.append(len(replacement_data))

    token_display_name = tokenize(option.display_name)
    display_names = [
        token_display_name for _ in range(max(replacement_data_list_lengths))
    ]
    for identifier, replacement_data in kwargs.items():
        if len(replacement_data) == 1:
            replacement_data_data = replacement_data[0]  # :-)
            kwargs[identifier] = [
                replacement_data_data for i in range(max(replacement_data_list_lengths))
            ]

    display_names_str: List[str] = []
    for i, display_name in enumerate(display_names):
        late_eval_replacement_dict = {}
        for (
            late_eval_key,
            late_eval_value,
        ) in display_name.late_evaluation_dynamic_stmts.items():
            late_eval_value = late_eval_value.lstrip(r"@{").rstrip(r"}£")
            try:
                late_eval_replacement_dict[late_eval_key] = str(
                    kwargs[late_eval_value][i]
                )
            except KeyError as e:
                e.add_note(
                    "Related to a display name late evaluation key being missing "
                    "from the provided kwargs"
                )
                raise e
            except IndexError as e:
                e.add_note("Exception caused by an unexpected lack of data in a kwarg")
                raise e

        display_names_str.append(
            display_name.subtracted_string.format(
                **(display_name.generation_time_operations | late_eval_replacement_dict)
            )
        )

    return display_names_str
