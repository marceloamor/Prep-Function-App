from ..base import Base

from sqlalchemy.orm import mapped_column, Mapped
from sqlalchemy import Text


class CounterpartyClearer(Base):
    __tablename__ = "lme_counterparty_clearer"

    counterparty: Mapped[str] = mapped_column(Text, primary_key=True)
    clearer: Mapped[str] = mapped_column(Text)
