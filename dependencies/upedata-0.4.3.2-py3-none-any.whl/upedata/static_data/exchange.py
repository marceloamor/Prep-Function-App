import upedata.static_data.product as product
from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Text

from typing import List


class Exchange(Base):
    __tablename__ = "exchanges"
    symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    name: Mapped[str] = mapped_column(Text, nullable=False)

    products: Mapped[List["product.Product"]] = relationship(back_populates="exchange")
