from ..static_data import currency
from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Date, Text, Double, ForeignKey

from datetime import date


class InterestRate(Base):
    __tablename__ = "interest_rates"

    published_date: Mapped[date] = mapped_column(Date, primary_key=True)
    to_date: Mapped[date] = mapped_column(Date, primary_key=True)
    currency_symbol: Mapped[str] = mapped_column(
        ForeignKey("currencies.symbol"), primary_key=True
    )
    source: Mapped[str] = mapped_column(Text, primary_key=True)
    continuous_rate: Mapped[float] = mapped_column(Double)

    currency: Mapped["currency.Currency"] = relationship()
