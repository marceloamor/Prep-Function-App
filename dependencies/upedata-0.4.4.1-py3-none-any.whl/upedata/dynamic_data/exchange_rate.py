from ..static_data import Currency
from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Date, DECIMAL, ForeignKey, Text

from decimal import Decimal
from datetime import date


class ExchangeRate(Base):
    __tablename__ = "exchange_rates"

    published_date: Mapped[date] = mapped_column(Date, primary_key=True)
    source: Mapped[str] = mapped_column(Text, primary_key=True)
    base_currency_symbol: Mapped[str] = mapped_column(
        ForeignKey("currencies.symbol"), primary_key=True
    )
    quote_currency_symbol: Mapped[str] = mapped_column(
        ForeignKey("currencies.symbol"), primary_key=True
    )
    forward_date: Mapped[date] = mapped_column(Date, primary_key=True)
    rate: Mapped[Decimal] = mapped_column(DECIMAL(20, 8))

    base_currency: Mapped["Currency"] = relationship(foreign_keys=base_currency_symbol)
    quote_currency: Mapped["Currency"] = relationship(
        foreign_keys=quote_currency_symbol
    )
