import upedata.static_data.future_price_feed_association as future_price_feed_association
import upedata.static_data.product as product
import upedata.static_data.option as option
from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import ForeignKey, Integer, DateTime, Text

from typing import List, Optional
from datetime import datetime


class Future(Base):
    __tablename__ = "futures"

    symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    display_name: Mapped[Optional[str]] = mapped_column(Text)
    expiry: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    multiplier: Mapped[int] = mapped_column(Integer)
    product_symbol: Mapped[str] = mapped_column(ForeignKey("products.symbol"))

    product: Mapped["product.Product"] = relationship(
        back_populates="futures", lazy="immediate"
    )
    underlying_feeds: Mapped[
        List["future_price_feed_association.FuturePriceFeedAssociation"]
    ] = relationship(back_populates="future")
    options: Mapped[List["option.Option"]] = relationship(
        back_populates="underlying_future"
    )

    def to_dict(self):
        product_dict = {}
        for field in self.__table__.c:
            product_dict[field.name] = getattr(self, field.name)

        return product_dict
