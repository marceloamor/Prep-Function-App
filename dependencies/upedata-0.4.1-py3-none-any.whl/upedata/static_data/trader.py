import upedata.static_data.portfolio as portfolio
from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Integer, Text, Boolean

from typing import List


class Trader(Base):
    __tablename__ = "traders"

    trader_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    display_name: Mapped[str] = mapped_column(Text)
    email: Mapped[str] = mapped_column(Text)
    full_name: Mapped[str] = mapped_column(Text)
    is_algo: Mapped[bool] = mapped_column(Boolean, default=False)

    portfolios: Mapped[List["portfolio.Portfolio"]] = relationship(
        back_populates="owner_trader"
    )
