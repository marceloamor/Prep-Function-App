import upedata.static_data.option as option
from ..enums import CallOrPut
from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import DATE as pg_DATE
from sqlalchemy import ForeignKey, Double, DECIMAL, Enum

from typing import Optional
import datetime


class OptionClosingPrice(Base):
    __tablename__ = "option_closing_prices"

    close_date: Mapped[datetime.date] = mapped_column(pg_DATE, primary_key=True)
    option_symbol: Mapped[str] = mapped_column(
        ForeignKey("options.symbol"), primary_key=True
    )
    option_strike: Mapped[float] = mapped_column(DECIMAL, primary_key=True)
    call_or_put: Mapped[CallOrPut] = mapped_column(
        Enum(CallOrPut, name="call_or_put"), primary_key=True
    )
    close_price: Mapped[Optional[float]] = mapped_column(Double)
    close_volatility: Mapped[Optional[float]] = mapped_column(Double)
    close_delta: Mapped[Optional[float]] = mapped_column(Double)

    option: Mapped["option.Option"] = relationship()
