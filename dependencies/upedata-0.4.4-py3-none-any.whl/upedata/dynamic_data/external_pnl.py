import upedata.static_data.portfolio as portfolio
import upedata.static_data.product as product
from ..base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Text, Float, Date, ForeignKey

from datetime import date


class ExternalPnL(Base):
    __tablename__ = "external_pnls"

    pnl_date: Mapped[date] = mapped_column(Date, primary_key=True)
    portfolio_id: Mapped[int] = mapped_column(
        ForeignKey("portfolios.portfolio_id"), primary_key=True
    )
    product_symbol: Mapped[str] = mapped_column(
        ForeignKey("products.symbol"), primary_key=True
    )
    source: Mapped[str] = mapped_column(Text, primary_key=True)
    t1_trades: Mapped[float] = mapped_column(Float)
    pos_pnl: Mapped[float] = mapped_column(Float)
    gross_pnl: Mapped[float] = mapped_column(Float)

    product: Mapped["product.Product"] = relationship(
        foreign_keys=product_symbol,
        back_populates="external_pnls",
    )
    portfolio: Mapped["portfolio.Portfolio"] = relationship(
        foreign_keys=portfolio_id,
        back_populates="external_pnls",
    )
